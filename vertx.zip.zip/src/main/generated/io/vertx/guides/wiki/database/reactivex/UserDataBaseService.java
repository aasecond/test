/*
 * Copyright 2014 Red Hat, Inc.
 *
 * Red Hat licenses this file to you under the Apache License, version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License.  You may obtain a copy of the License at:
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

package io.vertx.guides.wiki.database.reactivex;

import java.util.Map;
import io.reactivex.Observable;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.Completable;
import io.reactivex.Maybe;
import io.vertx.core.json.JsonArray;
import java.util.List;
import io.vertx.core.json.JsonObject;
import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;

/**
 *
 * <p/>
 * NOTE: This class has been automatically generated from the {@link io.vertx.guides.wiki.database.UserDataBaseService original} non RX-ified interface using Vert.x codegen.
 */

@io.vertx.lang.reactivex.RxGen(io.vertx.guides.wiki.database.UserDataBaseService.class)
public class UserDataBaseService {

  @Override
  public String toString() {
    return delegate.toString();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    UserDataBaseService that = (UserDataBaseService) o;
    return delegate.equals(that.delegate);
  }
  
  @Override
  public int hashCode() {
    return delegate.hashCode();
  }

  public static final io.vertx.lang.reactivex.TypeArg<UserDataBaseService> __TYPE_ARG = new io.vertx.lang.reactivex.TypeArg<>(
    obj -> new UserDataBaseService((io.vertx.guides.wiki.database.UserDataBaseService) obj),
    UserDataBaseService::getDelegate
  );

  private final io.vertx.guides.wiki.database.UserDataBaseService delegate;
  
  public UserDataBaseService(io.vertx.guides.wiki.database.UserDataBaseService delegate) {
    this.delegate = delegate;
  }

  public io.vertx.guides.wiki.database.UserDataBaseService getDelegate() {
    return delegate;
  }

  public UserDataBaseService fetchAllUsers(Handler<AsyncResult<JsonArray>> resultHandler) { 
    delegate.fetchAllUsers(resultHandler);
    return this;
  }

  public Single<JsonArray> rxFetchAllUsers() { 
    return new io.vertx.reactivex.core.impl.AsyncResultSingle<JsonArray>(handler -> {
      fetchAllUsers(handler);
    });
  }

  public UserDataBaseService fetchUser(String username, Handler<AsyncResult<JsonObject>> resultHandler) { 
    delegate.fetchUser(username, resultHandler);
    return this;
  }

  public Single<JsonObject> rxFetchUser(String username) { 
    return new io.vertx.reactivex.core.impl.AsyncResultSingle<JsonObject>(handler -> {
      fetchUser(username, handler);
    });
  }

  public UserDataBaseService fetchUserById(int id, Handler<AsyncResult<JsonObject>> resultHandler) { 
    delegate.fetchUserById(id, resultHandler);
    return this;
  }

  public Single<JsonObject> rxFetchUserById(int id) { 
    return new io.vertx.reactivex.core.impl.AsyncResultSingle<JsonObject>(handler -> {
      fetchUserById(id, handler);
    });
  }

  public UserDataBaseService fetchUserByName(String username, Handler<AsyncResult<JsonObject>> resultHandler) { 
    delegate.fetchUserByName(username, resultHandler);
    return this;
  }

  public Single<JsonObject> rxFetchUserByName(String username) { 
    return new io.vertx.reactivex.core.impl.AsyncResultSingle<JsonObject>(handler -> {
      fetchUserByName(username, handler);
    });
  }

  public UserDataBaseService createUser(String username, String password, Handler<AsyncResult<Void>> resultHandler) { 
    delegate.createUser(username, password, resultHandler);
    return this;
  }

  public Completable rxCreateUser(String username, String password) { 
    return new io.vertx.reactivex.core.impl.AsyncResultCompletable(handler -> {
      createUser(username, password, handler);
    });
  }

  public UserDataBaseService saveUser(String password, String username, Handler<AsyncResult<Void>> resultHandler) { 
    delegate.saveUser(password, username, resultHandler);
    return this;
  }

  public Completable rxSaveUser(String password, String username) { 
    return new io.vertx.reactivex.core.impl.AsyncResultCompletable(handler -> {
      saveUser(password, username, handler);
    });
  }

  public UserDataBaseService deleteUser(String username, Handler<AsyncResult<Void>> resultHandler) { 
    delegate.deleteUser(username, resultHandler);
    return this;
  }

  public Completable rxDeleteUser(String username) { 
    return new io.vertx.reactivex.core.impl.AsyncResultCompletable(handler -> {
      deleteUser(username, handler);
    });
  }

  public UserDataBaseService fetchAllUsersData(Handler<AsyncResult<List<JsonObject>>> resultHandler) { 
    delegate.fetchAllUsersData(resultHandler);
    return this;
  }

  public Single<List<JsonObject>> rxFetchAllUsersData() { 
    return new io.vertx.reactivex.core.impl.AsyncResultSingle<List<JsonObject>>(handler -> {
      fetchAllUsersData(handler);
    });
  }


  public static  UserDataBaseService newInstance(io.vertx.guides.wiki.database.UserDataBaseService arg) {
    return arg != null ? new UserDataBaseService(arg) : null;
  }
}
