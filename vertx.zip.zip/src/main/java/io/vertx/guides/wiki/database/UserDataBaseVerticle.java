/*
 *  Copyright (c) 2017 Red Hat, Inc. and/or its affiliates.
 *  Copyright (c) 2017 INSA Lyon, CITI Laboratory.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.vertx.guides.wiki.database;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.jdbc.JDBCClient;
import io.vertx.serviceproxy.ServiceBinder;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Properties;

/**
 * @author <a href="https://julien.ponge.org/">Julien Ponge</a>
 */
public class UserDataBaseVerticle extends AbstractVerticle {

  public static final String CONFIG_USERDB_JDBC_URL = "userdb.jdbc.url";
  public static final String CONFIG_USERDB_JDBC_DRIVER_CLASS = "userdb.jdbc.driver_class";
  public static final String CONFIG_USERDB_JDBC_MAX_POOL_SIZE = "userdb.jdbc.max_pool_size";
  public static final String CONFIG_USERDB_SQL_QUERIES_RESOURCE_FILE = "userdb.sqlqueries.resource.file";
  public static final String CONFIG_USERDB_QUEUE = "userdb.queue";

  @Override
  public void start(Future<Void> startFuture) throws Exception {

    HashMap<UserSqlQuery, String> sqlQueries = loadSqlQueries();

    JDBCClient dbClient = JDBCClient.createShared(vertx, new JsonObject()
      .put("url", config().getString(CONFIG_USERDB_JDBC_URL, "jdbc:hsqldb:file:db/users"))
      .put("driver_class", config().getString(CONFIG_USERDB_JDBC_DRIVER_CLASS, "org.hsqldb.jdbcDriver"))
      .put("max_pool_size", config().getInteger(CONFIG_USERDB_JDBC_MAX_POOL_SIZE, 30)));

    UserDataBaseService.create(dbClient, sqlQueries, ready -> {
      if (ready.succeeded()) {
        ServiceBinder binder = new ServiceBinder(vertx);
        binder.setAddress(CONFIG_USERDB_QUEUE).register(UserDataBaseService.class, ready.result());
        startFuture.complete();
      } else {
        startFuture.fail(ready.cause());
      }
    });
  }

  /*
   * Note: this uses blocking APIs, but data is small...
   */
  private HashMap<UserSqlQuery, String> loadSqlQueries() throws IOException {

    String queriesFile = config().getString(CONFIG_USERDB_SQL_QUERIES_RESOURCE_FILE);
    InputStream queriesInputStream;
    if (queriesFile != null) {
      queriesInputStream = new FileInputStream(queriesFile);
    } else {
      queriesInputStream = getClass().getResourceAsStream("/userdb-queries.properties");
    }

    Properties queriesProps = new Properties();
    queriesProps.load(queriesInputStream);
    queriesInputStream.close();

    HashMap<UserSqlQuery, String> sqlQueries = new HashMap<>();
    sqlQueries.put(UserSqlQuery.CREATE_USERS_TABLE, queriesProps.getProperty("create-users-table"));
    sqlQueries.put(UserSqlQuery.ALL_USERS, queriesProps.getProperty("all-users"));
    sqlQueries.put(UserSqlQuery.GET_USER, queriesProps.getProperty("get-user"));
    sqlQueries.put(UserSqlQuery.CREATE_USER, queriesProps.getProperty("create-user"));
    sqlQueries.put(UserSqlQuery.SAVE_USER, queriesProps.getProperty("save-user"));
    sqlQueries.put(UserSqlQuery.DELETE_USER, queriesProps.getProperty("delete-user"));
    sqlQueries.put(UserSqlQuery.ALL_USERS_DATA, queriesProps.getProperty("all-users-data"));
    sqlQueries.put(UserSqlQuery.GET_USER_BY_ID, queriesProps.getProperty("get-user-by-id"));
    sqlQueries.put(UserSqlQuery.GET_USER_BY_NAME, queriesProps.getProperty("get-user-by-name"));
    return sqlQueries;
  }
}
