/*
 *  Copyright (c) 2017 Red Hat, Inc. and/or its affiliates.
 *  Copyright (c) 2017 INSA Lyon, CITI Laboratory.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.vertx.guides.wiki.database;

import io.reactivex.Flowable;
import io.reactivex.Single;
import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.sql.ResultSet;
import io.vertx.reactivex.CompletableHelper;
import io.vertx.reactivex.SingleHelper;
import io.vertx.reactivex.ext.jdbc.JDBCClient;
import io.vertx.reactivex.ext.sql.SQLConnection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;

/**
 * @author <a href="https://julien.ponge.org/">Julien Ponge</a>
 */
class UerDataBaseServiceImpl implements UserDataBaseService {

  private static final Logger LOGGER = LoggerFactory.getLogger(WikiDatabaseServiceImpl.class);

  private final HashMap<UserSqlQuery, String> sqlQueries;
  private final JDBCClient dbClient;

  UerDataBaseServiceImpl(io.vertx.ext.jdbc.JDBCClient dbClient, HashMap<UserSqlQuery, String> sqlQueries, Handler<AsyncResult<UserDataBaseService>> readyHandler) {
    this.dbClient = new JDBCClient(dbClient);
    this.sqlQueries = sqlQueries;

    getConnection()
      .flatMapCompletable(conn -> conn.rxExecute(sqlQueries.get(UserSqlQuery.CREATE_USERS_TABLE)))
      .andThen(Single.just(this))
      .subscribe(SingleHelper.toObserver(readyHandler));
  }

  private Single<SQLConnection> getConnection() {
    return dbClient.rxGetConnection().flatMap(conn -> {
      Single<SQLConnection> connectionSingle = Single.just(conn);
      return connectionSingle.doFinally(conn::close);
    });
  }

  @Override
  public UserDataBaseService fetchAllUsers(Handler<AsyncResult<JsonArray>> resultHandler) {
    dbClient.rxQuery(sqlQueries.get(UserSqlQuery.ALL_USERS))
      .flatMapPublisher(res -> {
        List<JsonArray> results = res.getResults();
        return Flowable.fromIterable(results);
      })
      .map(json -> json.getString(0))
      .sorted()
      .collect(JsonArray::new, JsonArray::add)
      .subscribe(SingleHelper.toObserver(resultHandler));
    return this;
  }

  @Override
  public UserDataBaseService fetchUser(String name, Handler<AsyncResult<JsonObject>> resultHandler) {
    dbClient.rxQueryWithParams(sqlQueries.get(UserSqlQuery.GET_USER), new JsonArray().add(name))
      .map(result -> {
        if (result.getNumRows() > 0) {
          JsonArray row = result.getResults().get(0);
          return new JsonObject()
            .put("found", true)
            .put("id", row.getInteger(0))
            .put("usernmame", row.getInteger(1))
            .put("password", row.getString(2));
        } else {
          return new JsonObject().put("found", false);
        }
      })
      .subscribe(SingleHelper.toObserver(resultHandler));
    return this;
  }

  @Override
  public UserDataBaseService fetchUserById(int id, Handler<AsyncResult<JsonObject>> resultHandler) {
    Single<ResultSet> resultSet = dbClient.rxQueryWithParams(
      sqlQueries.get(UserSqlQuery.GET_USER_BY_ID), new JsonArray().add(id));
    resultSet
      .map(result -> {
        if (result.getNumRows() > 0) {
          JsonObject row = result.getRows().get(0);
          return new JsonObject()
            .put("found", true)
            .put("id", row.getInteger("ID"))
            .put("username", row.getString("UserName"))
            .put("password", row.getString("Password"));
        } else {
          return new JsonObject().put("found", false);
        }
      })
      .subscribe(SingleHelper.toObserver(resultHandler));
    return this;
  }

  @Override
  public UserDataBaseService fetchUserByName(String name, Handler<AsyncResult<JsonObject>> resultHandler) {
    Single<ResultSet> resultSet = dbClient.rxQueryWithParams(
      sqlQueries.get(UserSqlQuery.GET_USER_BY_NAME), new JsonArray().add(name));
    resultSet
      .map(result -> {
        if (result.getNumRows() > 0) {
          JsonObject row = result.getRows().get(0);
          return new JsonObject()
            .put("found", true)
            .put("id", row.getInteger("ID"))
            .put("username", row.getString("USERNAME"))
            .put("password", row.getString("PASSWORD"));
        } else {
          return new JsonObject().put("found", false);
        }
      })
      .subscribe(SingleHelper.toObserver(resultHandler));
    return this;
  }

  @Override
  public UserDataBaseService createUser(String username, String password, Handler<AsyncResult<Void>> resultHandler) {
    LOGGER.info("create user with username " + username + " password: " +password);
    dbClient.rxUpdateWithParams(sqlQueries.get(UserSqlQuery.CREATE_USER), new JsonArray().add(username).add(password))
      .toCompletable()
      .subscribe(CompletableHelper.toObserver(resultHandler));
    return this;
  }

  @Override
  public UserDataBaseService saveUser(String password, String username, Handler<AsyncResult<Void>> resultHandler) {
    LOGGER.info("Update user with username: "+username + " password: "+password);
    dbClient.rxUpdateWithParams(sqlQueries.get(UserSqlQuery.SAVE_USER), new JsonArray().add(password).add(username))
      .toCompletable()
      .subscribe(CompletableHelper.toObserver(resultHandler));
    return this;
  }

  @Override
  public UserDataBaseService deleteUser(String username, Handler<AsyncResult<Void>> resultHandler) {
    JsonArray data = new JsonArray().add(username);
    dbClient.rxUpdateWithParams(sqlQueries.get(UserSqlQuery.DELETE_USER), data)
      .toCompletable()
      .subscribe(CompletableHelper.toObserver(resultHandler));
    return this;
  }

  @Override
  public UserDataBaseService fetchAllUsersData(Handler<AsyncResult<List<JsonObject>>> resultHandler) {
    dbClient.rxQuery(sqlQueries.get(UserSqlQuery.ALL_USERS_DATA))
      .map(ResultSet::getRows)
      .subscribe(SingleHelper.toObserver(resultHandler));
    return this;
  }
}
