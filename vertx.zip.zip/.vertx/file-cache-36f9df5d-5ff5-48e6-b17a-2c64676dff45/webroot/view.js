// controller
angular.module("userApp", [])
.controller('LoginController', function($scope, $rootScope, AUTH_EVENTS, AuthService) {
  $scope.user = {
     username : '',
     password : ''
};
  $scope.login = function(user) {
    console.log('login', user);
    AuthService.login(user).then(function(user) {
        $rootScope.$broadcast(AUTH_EVENTS.loginSuccess);
        $scope.$parent.setCurrentUser(user);
    }, function() {
        $rootScope.$broadcast(AUTH_EVENTS.loginFailed);
    });
  };
})
